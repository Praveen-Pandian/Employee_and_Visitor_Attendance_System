<?php
$servername = "localhost";
$username = "root";
$dbpassword = "";
$dbname = "quadsel";

$con = mysqli_connect($servername, $username, $dbpassword, $dbname);
?>